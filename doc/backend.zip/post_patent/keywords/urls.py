from rest_framework import routers
from .views import KeywordsViewSet

router = routers.SimpleRouter()
router.register('', KeywordsViewSet)
urlpatterns = router.urls