from django.contrib import admin
from .models import Patent

# Register your models here.
admin.site.register(Patent)