from rest_framework_nested import routers
from .views import PatentsViewSet, SearchViewSet
from django.urls import path, include

router = routers.SimpleRouter()
router.register('', PatentsViewSet)

search_router = routers.NestedSimpleRouter(router, '', lookup='keyword')
search_router.register('keyword', SearchViewSet, basename='patent-keyword')

urlpatterns = [
    path(r'', include(router.urls)),
    path(r'', include(search_router.urls)),
]